<?php

namespace Core;

class Config
{
    
    const DEBUG			= true;
	const SHOW_ERRORS	= false;
	const LOG_ERRORS	= false;

    const KEY_64 = 'LIUbn796voYGBVBtg7iFTYUv856c47iRugboliN&p80np098n+:298n0865v(¨&';

    const DOMAIN = 'http://localhost/';

    const PATH ="C:".DIRECTORY_SEPARATOR."xampp".DIRECTORY_SEPARATOR."htdocs".DIRECTORY_SEPARATOR."boe-php".DIRECTORY_SEPARATOR."App".DIRECTORY_SEPARATOR."Files".DIRECTORY_SEPARATOR;

    const FOLDER  ='boe-python';

    const INI = 'NORMAL';

    const OFF = 'OFFLINE';

    const ASSETS =self::DOMAIN.self::FOLDER.'/App/Views/assets/';

    const DB_HOST = '192.168.210.40';

    const DB_NAME = 'Vision';

    const DB_USER = 'postgres';

    const DB_PASS = "2Smx'P?8[#RA\#9Z";

    const URL = self::DOMAIN.self::FOLDER.'/';

    const FILES = self::DOMAIN.self::FOLDER.'/App/Files/';

    public function __construct($INIT)
    {
        $this->bootstrap($INIT);
    }   

    protected function bootstrap($INIT)
    {
        switch($INIT)
        {
            case  'NORMAL':
            break;
            default: 
                 \App\View::render('Offline/index'); die();
            break;
        }
    }
}

?>