<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - ERROR 401</title>
  <link rel="stylesheet" href="<?php  echo $_SERVER['assets'];?>401.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="world">
  <div class="bottomline">Desculpe, mas esta página é proibida<br> <a href="https://www.sogou.com" target="_blank">ERROR 401</a></div>
  <div class="room">
    <div class="lantern">
      <span><a>光</a></span>
      <span><a>金</a></span>
      <span><a>光</a></span>
      <span><a>金</a></span>
    </div>
    <div class="windows">
      <span></span>
      <span></span>
      <span></span>
    </div>
    <div class="panel">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
    </div>
    <div class="tabletop"></div>
    <div class="table"></div>
    <div class="cup">
      <span></span>
      <span></span>
      <span></span>
    </div>
    <div class="chopsticks"></div>

    <div class="plate">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
    </div>
    <div class="wasabi-pot"></div>
    <div class="chopstick-pot"></div>

    <div class="chopsticks2"></div>
    <div class="chopsticks3"></div>
    <div class="wasabi"></div>
    <div class="belt">

      <div class="sushiplate">
        <span><div class="rice"></div><div class="salmon"></div><div class="seaweed"></div></span>
        <span><div class="rice"></div><div class="salmon"></div><div class="seaweed3"></div></span>
        <span><div class="rice2"></div><div class="rice3"></div><div class="rice4"></div></span>
        <span><div class="rice"></div><div class="tuna"></div><div class="seaweed"></div></span>
        <span><div class="rice"></div><div class="roe"></div><div class="seaweed2"></div></span>
      </div>
    </div>
  </div>
</div>
<!-- partial -->
  
</body>
</html>
