<?php

namespace App\Controllers\Vision;

use  App\Controllers\Crud;

class Vision
{
    public function __construct()
    {
        $this->model = new App\Controllers\Crud();
    }

    protected function before()
    {
        if(empty($_REQUEST))
        {
            echo json_decode(['code'=>303, 'msg'=>'O request não pode ser vazio']); die();
        }
    }

    protected function after()
    {
        unset($this->model);
    }

    public function Save()
    {
        $this->before();
        // insert($table, $fields, $values, array $params)
        $serverDate =  date("Y-m-d,h:m:s");
        $p = $this->model->insert('headcount','qtd_person, datahora,datahoraservidor ',[$_REQUEST['qtd_person'], $_REQUEST['datahora'],serverDate] );
        if($p)
        {
            echo json_encode(['code'=>200,'msg'=>'dados salvos com sucesso']); die();
        }
        $this->after();
    }

    public function getData()
    {
        $this->before();
        if(isset($_REQUEST['limit']))
        {
            $limit = $_REQUEST['limit'];
        }
        else 
        {
            $limit='';
        }
        $ret = $this->model->getAll(' * ', 'headcount', '', $limit);
        if(!empty($ret) && sizeof($ret)>0)
        {
            echo json_encode(['code'=>200,'data'=>$ret]); die();
        }
        else
        {
            echo json_encode(['code'=>303,'data'=>'Sem dados']); die();
        }
    }

    protected $model;
}

?>