<?php
date_default_timezone_set('America/Sao_Paulo');

require_once('vendor/autoload.php');

new \Core\Config(\Core\Config::INI);

$router = new  \Core\Router();
$handler = new \Core\Handler();

$router->before('GET', '/.*', function() 
{
    global $handler;
    if(!isset($_GET['csrf']))
    {
        $handler->handle($handler::CALLABLE,  "App\View@render" ,'401/index' ); die();
    }
});

$router->before('POST', '/.*', function() 
{
    global $handler;
    if(!isset($_POST['csrf']))
    {
        $handler->handle($handler::CALLABLE,  "App\View@render" ,'401/index' );die();
    }
});

$router->post('/vision/headcount/put',function(){
    global $handler;
    $handler->handle($handler::CALLABLE,  "App\Controllers\Vision@Save" ,$_REQUEST );
});

$router->get('/vision/headcount/getall',function(){
    global $handler;
    $handler->handle($handler::CALLABLE,  "App\Controllers\Vision@getData" ,$_REQUEST );
});


$router->set404(function() 
{
    global $handler;
    $handler->handle($handler::CALLABLE,  "App\View@render" ,'404/index' );die();
});

try
{
    $router->run();
}
catch(Exception $e)
{
    echo $e->getMessage(); die();
}
   

?>